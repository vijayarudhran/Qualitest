package stepdefinition;



import java.io.File;
import java.util.List;

import org.junit.Assert;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.junit.Cucumber;

public class login {
	
	WebDriver driver;
	WebDriverWait wait;

    @Given("^User able to launch portal with url \"([^\"]*)\"$")
    public void launch_portal(String url) throws Throwable {
    	
    	System.out.println("printing given - background");
    	driver = new ChromeDriver();		//launching browser
		driver.get(url);	//re-directing to specified url
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver,5);
        
    }
    
    @When("^User logs in as username \"([^\"]*)\" and Password as \"([^\"]*)\"$")
    public void user_log_in(String u_name, String pwd) throws Throwable {
    	//System.setProperty("webdriver.chrome.driver");
		performClick(driver.findElement(By.linkText("Sign in")));
		inputValue(driver.findElement(By.id("email")),u_name);
		inputValue(driver.findElement(By.name("passwd")),pwd);
		performClick(driver.findElement(By.name("SubmitLogin")));
		//Thread.sleep(5000);
    }
    
    @Given("^User logs in successfully to online shopping portal$")
    public void user_login_successful() throws Throwable {   
    	Assert.assertTrue(driver.findElement(By.xpath("//div[@id='block_top_menu']/ul")).isDisplayed());
    }
    
    @When("^User search for T-shirt$")
    public void user_search_tshirt() throws Throwable {
    	WebElement menuUL= driver.findElement(By.xpath("//div[@id='block_top_menu']/ul"));
		List<WebElement> menuList=menuUL.findElements(By.tagName("li"));
		for (WebElement li : menuList) {
			if (li.getText().equalsIgnoreCase("T-shirts")) {
			     li.click();
			   }
		}  
    }
    
    @Given("^Add to cart to place order")
    public void place_order() throws Throwable {
    	waitUntil(driver.findElement(By.xpath("//div[@id='center_column']/ul/li")));
		Actions a = new Actions(driver);
		a.moveToElement(driver.findElement(By.xpath("//div[@id='center_column']/ul/li"))).
		build().perform();
		
		performClick(driver.findElement(By.xpath("//a[@title='Add to cart']")));
		
		performClick(driver.findElement(By.xpath("//a[@title='Proceed to checkout']")));
    
    }
    
    @Then("^Order should be successful$")
    public void verify_order_status() throws Throwable {
    	//summary
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		performClick(driver.findElement(By.xpath("//div[@id='center_column']/p/a[@title='Proceed to checkout']")));
		
		//address
		performClick(driver.findElement(By.xpath("//button[@name='processAddress']")));
		
		//shipping
		performClick(driver.findElement(By.id("cgv")));
		performClick(driver.findElement(By.xpath("//button[@name='processCarrier']")));
		
		//payment
		performClick(driver.findElement(By.xpath("//a[@title='Pay by bank wire']")));
		performClick(driver.findElement(By.xpath("//p[@id='cart_navigation']/button")));
		
		
		Thread.sleep(2000);
		takeSnapShot(driver,"./Screenshots/OrderPlaced.png");
    
    }
    
    @And("^order history should display the T-shirt order details placed$")
    public void verify_order_history() throws Throwable {
   
    }
    
    public void performClick(WebElement obj) {
    	wait.until(ExpectedConditions.visibilityOf(obj));
    	obj.click();
    }
    
    public void inputValue(WebElement obj, String val) {
    	wait.until(ExpectedConditions.visibilityOf(obj));
    	obj.sendKeys(val);;
    }
    
    public void waitUntil(WebElement obj) {
    	wait.until(ExpectedConditions.visibilityOf(obj));
    }
    
    public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{

        //Convert web driver object to TakeScreenshot

        TakesScreenshot scrShot =((TakesScreenshot)webdriver);

        //Call getScreenshotAs method to create image file

                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

            //Move image file to new destination

                File DestFile=new File(fileWithPath);

                //Copy file at destination
                FileHandler.copy(SrcFile, DestFile);

    }  
}