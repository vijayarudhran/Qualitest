package com.Test.utils;

import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.Test.stepDef.CommonSteps;

import io.cucumber.java.Scenario;

public class DependencyUtil {

	public Scenario scenario;
	
	public static void performClick(WebElement obj) {
		CommonSteps.wait.until(ExpectedConditions.visibilityOf(obj));
    	obj.click();
    }
    
    public static void inputValue(WebElement obj, String val) {
    	CommonSteps.wait.until(ExpectedConditions.visibilityOf(obj));
    	obj.sendKeys(val);;
    }
    
    public static void waitUntil(WebElement obj) {
    	CommonSteps.wait.until(ExpectedConditions.visibilityOf(obj));
    }
    
    public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{

        //Convert web driver object to TakeScreenshot

        TakesScreenshot scrShot =((TakesScreenshot)webdriver);

        //Call getScreenshotAs method to create image file

                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

            //Move image file to new destination

                File DestFile=new File(fileWithPath);

                //Copy file at destination
                FileHandler.copy(SrcFile, DestFile);

    } 
	
}
