package com.Test.app;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.Test.stepDef.CommonSteps;
import com.Test.utils.DependencyUtil;

public class Order {
	
	Actions a = new Actions(CommonSteps.driver);
	
	public void search() {
		
		WebElement menuUL= CommonSteps.driver.findElement(By.xpath("//div[@id='block_top_menu']/ul"));
		List<WebElement> menuList=menuUL.findElements(By.tagName("li"));
		for (WebElement li : menuList) {
			if (li.getText().equalsIgnoreCase("T-shirts")) {
			     li.click();
			   }
		} 
	}
	
	public void add_to_cart() {
		
		DependencyUtil.waitUntil(CommonSteps.driver.findElement(By.xpath("//div[@id='center_column']/ul/li")));
		
		a.moveToElement(CommonSteps.driver.findElement(By.xpath("//div[@id='center_column']/ul/li"))).
		build().perform();
		
		DependencyUtil.performClick(CommonSteps.driver.findElement(By.xpath("//a[@title='Add to cart']")));
		
		DependencyUtil.performClick(CommonSteps.driver.findElement(By.xpath("//a[@title='Proceed to checkout']")));
		
	}
	
	public void place_order() throws Exception {
		
		//summary
		JavascriptExecutor js = (JavascriptExecutor) CommonSteps.driver;
		js.executeScript("window.scrollBy(0,1000)");
		DependencyUtil.performClick(CommonSteps.driver.findElement(By.xpath("//div[@id='center_column']/p/a[@title='Proceed to checkout']")));
		
		//address
		DependencyUtil.performClick(CommonSteps.driver.findElement(By.xpath("//button[@name='processAddress']")));
		
		//shipping
		js.executeScript("window.scrollBy(0,1000)");
		//CommonSteps.driver.navigate().refresh();
		//WebElement chkBox = CommonSteps.driver.findElement(By.xpath("//input[@id='cgv']"));
		CommonSteps.driver.findElement(By.xpath("//input[@id='cgv']")).click();
		//DependencyUtil.performClick(chkBox);
		DependencyUtil.performClick(CommonSteps.driver.findElement(By.xpath("//button[@name='processCarrier']")));
		
		//payment
		DependencyUtil.performClick(CommonSteps.driver.findElement(By.xpath("//a[@title='Pay by bank wire']")));
		DependencyUtil.performClick(CommonSteps.driver.findElement(By.xpath("//p[@id='cart_navigation']/button")));
		
		
		Thread.sleep(2000);
		DependencyUtil.takeSnapShot(CommonSteps.driver,"./Screenshots/OrderPlaced.png");
	}

}
