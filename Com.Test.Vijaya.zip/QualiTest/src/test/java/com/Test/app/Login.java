package com.Test.app;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Test.stepDef.CommonSteps;
import com.Test.utils.DependencyUtil;

public class Login {
	
	public void lauchApp(String url) {
		
		CommonSteps.driver = new ChromeDriver();		//launching browser
		
		CommonSteps.driver.get(url);	//re-directing to specified url
		
		CommonSteps.driver.manage().window().maximize();
		
		CommonSteps.wait = new WebDriverWait(CommonSteps.driver,25);
		
	}
	
	public void loginUser(String user, String pwd) {
		
		DependencyUtil.performClick(CommonSteps.driver.findElement(By.linkText("Sign in")));
    	
    	DependencyUtil.inputValue(CommonSteps.driver.findElement(By.id("email")),user);
    	
    	DependencyUtil.inputValue(CommonSteps.driver.findElement(By.name("passwd")),pwd);
    	
    	DependencyUtil.performClick(CommonSteps.driver.findElement(By.name("SubmitLogin")));
	}
	
	public void verify_Login() {
		
		Assert.assertTrue(CommonSteps.driver.findElement(By.xpath("//div[@id='block_top_menu']/ul")).isDisplayed());
	}

}
