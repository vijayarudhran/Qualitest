package com.Test.stepDef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Test.app.Login;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CommonSteps {
	
	public static WebDriver driver;
	public static WebDriverWait wait;
	Login login = new Login();

    @Given("^User able to launch portal with url \"([^\"]*)\"$")
    public void launch_portal(String url) throws Throwable {
    	
    	login.lauchApp(url);
    	       
    }
    
    @When("^User logs in as username \"([^\"]*)\" and Password as \"([^\"]*)\"$")
    public void user_log_in(String u_name, String pwd) throws Throwable {
 
    	login.loginUser(u_name, pwd);
    	
    }
    
    @And("^User logs in successfully to online shopping portal$")
    public void user_login_successful() throws Throwable {   
    	
    	login.verify_Login();
    }

}
