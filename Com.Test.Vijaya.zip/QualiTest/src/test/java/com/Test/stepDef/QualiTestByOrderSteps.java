package com.Test.stepDef;

import com.Test.app.Order;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class QualiTestByOrderSteps {
	
	Order order = new Order();
    
    @When("^User search for T-shirt$")
    public void user_search_tshirt() throws Throwable {
    	 
    	order.search();
    	
    }
    
    @Given("^Add to cart to place order")
    public void place_order() throws Throwable {
    	
    	order.add_to_cart();
    
    }
    
    @Then("^Order should be successful$")
    public void verify_order_status() throws Throwable {
    	
    	order.place_order();
    
    }
    
    @And("^order history should display the T-shirt order details placed$")
    public void verify_order_history() throws Throwable {
   
    }
    
    

}
