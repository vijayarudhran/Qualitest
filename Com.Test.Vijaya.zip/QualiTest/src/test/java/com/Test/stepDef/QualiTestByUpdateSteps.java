package com.Test.stepDef;

import com.Test.app.Update;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class QualiTestByUpdateSteps {
	
	Update update = new Update();
    
    @When("^User changes the first name of personal Information in settings by editing$")
    public void user_search_tshirt() throws Throwable {
    	 
    	
    	
    }
    
    @Then("^changes made to first name of the user should get update")
    public void place_order() throws Throwable {
    	
    	
    
    }
    
    @And("^reflect in the personal Information view as well$")
    public void verify_order_status() throws Throwable {
    	
    	
    	
    }
    

}
