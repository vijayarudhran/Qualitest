package com.Test.hooks;



import com.Test.utils.DependencyUtil;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;



public class Hooks {
	
	DependencyUtil service;
	
	public Hooks(DependencyUtil service) {
		this.service = service;
	}

	
	@Before
	public void beforeScenario(Scenario scenario) {
		service.scenario = scenario;
		System.out.println("Scenario starts here... " + service.scenario.getName());
		//service.scenario.write("Scenario starts here...");
	}
	
	@After
	public void afterScenario(Scenario scenario) {
		System.out.println("Scenario ends here...");
		//service.scenario.write("Scenario ends here...");
	}
}
