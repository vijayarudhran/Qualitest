package com.Test.runners;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "classpath:features", 
		glue = { "com.Test.stepDef"},//, "com.Test.hooks" }, 
		plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
				"html:target/cucumber-pretty-report/regression-tests","json:target/cucumber.json" }, 
		//monochrome = true,
		tags = "@Order"
)
		


public class TestRunner {

	
	
}
